package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Passenger;
import com.example.demo.repository.PassengerRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class PassengerController {
	@Autowired
	PassengerRepository passrepository;
	
	@PostMapping("/insertPassenger")
	public ResponseEntity<Passenger> addPassenger(@RequestBody Passenger p1){
		try {
			Passenger _pass=passrepository.save(new Passenger(p1.getName(),p1.getAge(),p1.getGender()));
			return new ResponseEntity<>(_pass,HttpStatus.CREATED);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/allpassengers")
	public ResponseEntity<List<Passenger>> getAllPassengers(){
		try {
		List<Passenger> passengers=new ArrayList<Passenger>();
		passrepository.findAll().forEach(passengers::add);
		return new ResponseEntity<>(passengers,HttpStatus.OK);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PutMapping("/editpassenger/{id}")
	public ResponseEntity<Passenger> updatePassenger(@PathVariable("id") int id,@RequestBody Passenger pass){
		Optional<Passenger> passData=passrepository.findById(id);
		if(passData.isPresent()) {
			Passenger passdata=passData.get();
			passdata.setName(pass.getName());
			passdata.setAge(pass.getAge());
			passdata.setGender(pass.getGender());
			return new ResponseEntity<>(passrepository.save(passdata),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/passenger/{id}")
	public ResponseEntity<Passenger> getUserbyId(@PathVariable("id") int id){
			Optional<Passenger> pass=passrepository.findById(id);
			if(pass.isPresent()) {
				return new ResponseEntity<>(pass.get(),HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
	}
	@DeleteMapping("/deletepassenger/{id}")
	public ResponseEntity<HttpStatus> deletePassenger(@PathVariable("id") int id){
		try {
			passrepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
