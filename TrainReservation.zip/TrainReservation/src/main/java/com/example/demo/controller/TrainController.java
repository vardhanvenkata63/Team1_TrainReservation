package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Train;
import com.example.demo.repository.TrainRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class TrainController {
	@Autowired
	TrainRepository trainrepository;
	@PostMapping("/insertTrain")
	public ResponseEntity<Train> createTrain(@RequestBody Train train){
		try {
			Train t=trainrepository.save(new Train(train.getTrainNo(),train.getTrainName(),train.getSource(),train.getDestination(),train.getTicketPrice()));
			return new ResponseEntity<>(t,HttpStatus.CREATED);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/alltrains")
	public ResponseEntity<List<Train>> allTrains(){
		try {
			List<Train> trains=new ArrayList<Train>();
			trainrepository.findAll().forEach(trains::add);
			return new ResponseEntity<>(trains,HttpStatus.OK);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PutMapping("/updatetrain/{id}")
	public ResponseEntity<Train> updateUser(@PathVariable("id") int id,@RequestBody Train train){
		Optional<Train> trainData=trainrepository.findById(id);
		if(trainData.isPresent()) {
			Train traindata=trainData.get();
			traindata.setTrainNo(train.getTrainNo());
			traindata.setTrainName(train.getTrainName());
			traindata.setSource(train.getSource());
			traindata.setDestination(train.getDestination());
			traindata.setTicketPrice(train.getTicketPrice());
			return new ResponseEntity<>(trainrepository.save(traindata),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/train/{id}")
	public ResponseEntity<Train> getUserbyId(@PathVariable("id") int id){
			Optional<Train> train=trainrepository.findById(id);
			if(train.isPresent()) {
				return new ResponseEntity<>(train.get(),HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
	}
	@DeleteMapping("/deletetrain/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") int id){
		try {
			trainrepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
